from machine import Pin, PWM
import time

# Setup buzzer on GP15
buzzer = PWM(Pin(15))

# Equal duration for each note (in seconds)
duration = 0.2

# Frequency range (in Hz)
start_freq = 200
end_freq = 2000
step = 200

while True:
    # Increasing frequency
    freq = start_freq
    while freq <= end_freq:
        buzzer.freq(freq)
        buzzer.duty_u16(32768)  # 50% duty cycle
        time.sleep(duration)
        freq += step

    # Decreasing frequency
    freq = end_freq
    while freq >= start_freq:
        buzzer.freq(freq)
        buzzer.duty_u16(32768)
        time.sleep(duration)
        freq -= step

    # Stop sound briefly
    buzzer.duty_u16(0)
    time.sleep(1)