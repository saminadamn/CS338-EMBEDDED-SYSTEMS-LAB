from machine import Pin, PWM
import time

# Ultrasonic
trig = Pin(0, Pin.OUT)
echo = Pin(1, Pin.IN)

# LED
led = Pin(2, Pin.OUT)

# Buzzer (PWM)
buzzer = PWM(Pin(14))

def get_distance():
    trig.low()
    time.sleep_us(2)
    trig.high()
    time.sleep_us(10)
    trig.low()

    while echo.value() == 0:
        start = time.ticks_us()

    while echo.value() == 1:
        end = time.ticks_us()

    duration = time.ticks_diff(end, start)
    distance = (duration * 0.0343) / 2
    return distance

while True:
    dist = get_distance()
    print("Depth:", dist, "cm")

    if dist < 100:
        led.on()
        print("Fish detected!")

        buzzer.freq(1000)         
        buzzer.duty_u16(32768)    # ON
        time.sleep(5)
        buzzer.duty_u16(0)        # OFF

    else:
        led.off()
        buzzer.duty_u16(0)

    time.sleep(0.5)