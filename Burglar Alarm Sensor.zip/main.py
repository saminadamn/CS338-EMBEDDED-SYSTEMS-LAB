from machine import Pin
import time

pir1 = Pin(0, Pin.IN)
pir2 = Pin(1, Pin.IN)
pir3 = Pin(2, Pin.IN)

led1 = Pin(28, Pin.OUT)
led2 = Pin(27, Pin.OUT)
led3 = Pin(26, Pin.OUT)

while True:
    # Room 1
    if pir1.value():
        led1.on()
        print("Room 1 Burglar is detected")
    else:
        led1.off()

    # Room 2
    if pir2.value():
        led2.on()
        print("Room 2 Burglar is detected")
    else:
        led2.off()

    # Room 3
    if pir3.value():
        led3.on()
        print("Room 3 Burglar is detected")
    else:
        led3.off()

    time.sleep(0.5)