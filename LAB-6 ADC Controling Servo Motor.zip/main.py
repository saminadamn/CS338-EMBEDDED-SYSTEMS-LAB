from machine import Pin, PWM, ADC
import time

SERVO_PIN = 15      
POT_PIN   = 28      

PWM_FREQ    = 50    
MIN_DUTY_US = 500  
MAX_DUTY_US = 2500  

servo = PWM(Pin(SERVO_PIN))
servo.freq(PWM_FREQ)

pot = ADC(Pin(POT_PIN))  


def angle_to_duty(angle):
    """Convert 0-180 degrees to 16-bit duty cycle."""
    angle     = max(0, min(180, angle))
    pulse_us  = MIN_DUTY_US + (MAX_DUTY_US - MIN_DUTY_US) * angle / 180
    period_us = 1_000_000 / PWM_FREQ          # 20000 us
    return int((pulse_us / period_us) * 65535)


def adc_to_angle(adc_val):
    """Map 16-bit ADC reading (0-65535) to 0-180 degrees."""
    return int(adc_val / 65535 * 180)


print("=== Potentiometer Servo Control ===")
print("GP28 (ADC) --> GP15 (Servo)")
print("Rotate the potentiometer to move the servo.\n")

prev_angle = -1

while True:
    adc_val = pot.read_u16()          # 0 - 65535
    angle   = adc_to_angle(adc_val)

    # Only update servo when angle changes by >= 1 degree (reduces jitter)
    if abs(angle - prev_angle) >= 1:
        servo.duty_u16(angle_to_duty(angle))
        print("ADC: {:5d}  -->  Angle: {:3d} deg".format(adc_val, angle))
        prev_angle = angle

    time.sleep_ms(20)   # 20 ms matches 50 Hz servo cycle