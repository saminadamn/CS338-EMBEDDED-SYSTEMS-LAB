from machine import Pin, I2C
from pico_i2c_lcd import I2cLcd
import utime
import random



i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=40000)
I2C_ADDR = 0x27


lcd = I2cLcd(i2c, I2C_ADDR, 2, 16)


leds = [
    Pin(10, Pin.OUT),
    Pin(11, Pin.OUT),
    Pin(12, Pin.OUT),
    Pin(13, Pin.OUT),
    Pin(14, Pin.OUT)
]

for led in leds:
    led.off()

lcd.clear()
lcd.putstr("Random No:")

while True:
    for led in leds:
        led.off()

    num = random.randint(1, 5)

    lcd.move_to(0, 1)
    lcd.putstr(" ")
    lcd.move_to(0, 1)
    lcd.putstr(str(num))

    leds[num - 1].on()
    utime.sleep(2)

