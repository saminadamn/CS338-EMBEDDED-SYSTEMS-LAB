from machine import Pin, I2C
from pico_i2c_lcd import I2cLcd
import utime
import random

i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=40000)

I2C_ADDR = 0x27

lcd = I2cLcd(i2c, I2C_ADDR, 2, 16)

lcd.clear()
lcd.putstr("Hello Embedded!")
