from machine import Pin, I2C
from pico_i2c_lcd import I2cLcd
import utime
import random

i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=40000)
I2C_ADDR = 0x27

lcd = I2cLcd(i2c, I2C_ADDR, 2, 16)
number = 5
lcd.clear()


text = "Embedded Systems Lab "
lcd.clear()

while True:
    for i in range(len(text)):
        lcd.move_to(0, 0)
        lcd.putstr(text[i:i+16])
        utime.sleep(0.3)

