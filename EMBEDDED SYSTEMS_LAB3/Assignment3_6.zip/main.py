from machine import Pin, I2C
from pico_i2c_lcd import I2cLcd
import utime
import random

i2c = I2C(0, sda=Pin(0), scl=Pin(1), freq=40000)
I2C_ADDR = 0x27

lcd = I2cLcd(i2c, I2C_ADDR, 2, 16)
number = 5
lcd.clear()

MAX_MOVES = 20
target_x = 10
target_y = 1

ball_x = random.randint(0, 15)
ball_y = random.randint(0, 1)

moves = 0
lcd.clear()

while moves < MAX_MOVES:
    lcd.clear()

    # draw target
    lcd.move_to(target_x, target_y)
    lcd.putstr("X")

    # draw ball
    lcd.move_to(ball_x, ball_y)
    lcd.putstr("O")

    if ball_x == target_x and ball_y == target_y:
        lcd.clear()
        lcd.putstr("YOU WIN!")
        lcd.move_to(0, 1)
        lcd.putstr("Moves: " + str(moves))
        break

    # random jump
    ball_x = random.randint(0, 15)
    ball_y = random.randint(0, 1)

    moves += 1
    utime.sleep(0.5)

else:
    lcd.clear()
    lcd.putstr("YOU LOSE")
    lcd.move_to(0, 1)
    lcd.putstr("Moves: " + str(moves))

